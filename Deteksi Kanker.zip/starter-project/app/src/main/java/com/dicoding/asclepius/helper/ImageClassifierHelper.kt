package com.dicoding.asclepius.helper

import android.content.ContentResolver
import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.net.Uri
import org.tensorflow.lite.Interpreter
import java.io.FileInputStream
import java.io.InputStream
import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.nio.MappedByteBuffer
import java.nio.channels.FileChannel

class ImageClassifierHelper(private val context: Context) {

    private lateinit var interpreter: Interpreter

    init {
        setupImageClassifier()
    }

    private fun loadModelFile(): MappedByteBuffer {
        val fileDescriptor = context.assets.openFd("cancer_classification.tflite")
        val inputStream = FileInputStream(fileDescriptor.fileDescriptor)
        val fileChannel = inputStream.channel
        val startOffset = fileDescriptor.startOffset
        val declaredLength = fileDescriptor.declaredLength
        return fileChannel.map(FileChannel.MapMode.READ_ONLY, startOffset, declaredLength)
    }

    private fun setupImageClassifier() {
        // Load the TensorFlow Lite model
        interpreter = Interpreter(loadModelFile())
    }

    fun classifyStaticImage(contentResolver: ContentResolver, imageUri: Uri): Pair<String, Float> {
        val inputStream: InputStream? = contentResolver.openInputStream(imageUri)
        val bitmap = BitmapFactory.decodeStream(inputStream)

        return if (bitmap != null) {
            val resizedBitmap = Bitmap.createScaledBitmap(bitmap, 224, 224, true)
            val input = convertBitmapToByteBuffer(resizedBitmap)
            val output = Array(1) { FloatArray(2) }

            interpreter.run(input, output)

            val isCancerDetected = output[0][1] > output[0][0]
            val confidenceScore = (output[0].maxOrNull() ?: 0f) * 100

            val roundedConfidenceScore = confidenceScore
            val diagnosis = if (isCancerDetected) "Cancer Detected" else "No Cancer Detected"
            Pair(diagnosis, roundedConfidenceScore)
        } else {
            Pair("Failed to load image", 0f)
        }
    }

    private fun convertBitmapToByteBuffer(bitmap: Bitmap): ByteBuffer {
        val byteBuffer = ByteBuffer.allocateDirect(4 * 224 * 224 * 3)
        byteBuffer.order(ByteOrder.nativeOrder())
        val intValues = IntArray(224 * 224)

        bitmap.getPixels(intValues, 0, 224, 0, 0, 224, 224)
        for (pixelValue in intValues) {
            byteBuffer.putFloat(((pixelValue shr 16 and 0xFF) - 127.5f) / 127.5f)
            byteBuffer.putFloat(((pixelValue shr 8 and 0xFF) - 127.5f) / 127.5f)
            byteBuffer.putFloat(((pixelValue and 0xFF) - 127.5f) / 127.5f)
        }
        return byteBuffer
    }
}
