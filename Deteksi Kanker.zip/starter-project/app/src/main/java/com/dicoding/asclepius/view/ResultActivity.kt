package com.dicoding.asclepius.view

import android.net.Uri
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import com.dicoding.asclepius.R
import com.dicoding.asclepius.databinding.ActivityResultBinding

class ResultActivity : AppCompatActivity() {
    private lateinit var binding: ActivityResultBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityResultBinding.inflate(layoutInflater)
        setContentView(binding.root)

        val prediction = intent.getStringExtra("EXTRA_PREDICTION")
        val confidence = intent.getFloatExtra("EXTRA_CONFIDENCE", 0f)
        val imageUri = intent.getParcelableExtra<Uri>("EXTRA_IMAGE_URI")

        displayResult(prediction ?: "Tidak ada prediksi", confidence, imageUri)
    }

    private fun displayResult(prediction: String, confidence: Float, imageUri: Uri?) {
        val confidenceInt = confidence.toInt()
        binding.resultText.text = "$prediction $confidenceInt%"

        if (imageUri != null) {
            binding.resultImage.setImageURI(imageUri)
        } else {
            binding.resultImage.setImageResource(R.drawable.ic_place_holder)
        }
    }
}